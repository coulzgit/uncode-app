@extends('admin/uncod/layouts.master')
@section('css')
<!-- Sidemenu-respoansive-tabs css -->
<link href="{{URL::asset('assets/plugins/sidemenu-responsive-tabs/css/sidemenu-responsive-tabs.css')}}" rel="stylesheet">
@endsection
@section('content')
<div class="col-lg-12 col-md-12">
						<div class="card">
							<div class="card-body">

								<div class="row">
								<div class="col-md-10 col-lg-8 col-xl-6 mx-auto d-block">
									<div class="card-sigin">
										<div class="main-signup-header">
											<h5> @if (session('message'))
                                            <div class="alert alert-success" role="alert">
                                                {{ session('message') }}
                                            </div>
                                        @endif</h5>
											<form method="POST" action="{{ route('client.inscri') }}">
													@csrf

													<div class="form-group row">
														<label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Prenom') }}</label>

														<div class="col-md-6">
															<input id="name" type="text" class="form-control @error('prenom') is-invalid @enderror" name="prenom" value="{{ old('prenom') }}" required autocomplete="prenom" autofocus>

															@error('prenom')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>

													<div class="form-group row">
														<label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Nom') }}</label>

														<div class="col-md-6">
															<input id="name" type="text" class="form-control @error('nom') is-invalid @enderror" name="nom" value="{{ old('nom') }}" required autocomplete="nom" autofocus>

															@error('nom')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>

													<div class="form-group row">
														<label for="tel" class="col-md-4 col-form-label text-md-right">{{ __('Tel') }}</label>

														<div class="col-md-6">
															<input id="tel" type="text" class="form-control @error('tel') is-invalid @enderror" name="tel" value="{{ old('tel') }}" required autocomplete="tel" autofocus>

															@error('tel')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>

													<div class="form-group row">
														<label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

														<div class="col-md-6">
															<input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

															@error('email')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>

													<div class="form-group row">
														<label for="nom_role" class="col-md-4 col-form-label text-md-right">{{ __('Role') }}</label>

														<div class="col-md-6">
                                                           <select class="form-control select2-no-search" name="nom_role" id="nom_role" required>
														   <option value="">Select Role</option>
														   @foreach($roles as $role)
														   <option value="{{$role->nom}}">{{$role->nom}}</option>
														   @endforeach
														   </select>
															@error('tel')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>

													<div class="form-group row">
														<label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

														<div class="col-md-6">
															<input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

															@error('password')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>

													<div class="form-group row">
														<label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

														<div class="col-md-6">
															<input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
														</div>
													</div>

													<div class="form-group row mb-0">
														<div class="col-md-6 offset-md-4">
															<button type="submit" class="btn btn-primary">
																{{ __('Ajouter') }}
															</button>
														</div>
													</div>
												</form>
										</div>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>








@endsection
@section('js')
@endsection
