<div class="col-xl-12">
	<div class="table-responsive">
		<div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
			
			<div class="row">
				<div class="col-sm-12">
					<table class="table text-md-nowrap dataTable no-footer" id="example1" role="grid" aria-describedby="example1_info">
						<thead>
							<tr role="row"><th class="wd-15p border-bottom-0 sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-sort="ascending" aria-label="First name: activate to sort column descending" style="width: 105px;">Nom</th><th class="wd-20p border-bottom-0 sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 153px;">Date de création</th><th class="wd-15p border-bottom-0 sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 104px;">Crée par</th>
							</tr>
						</thead>
						<tbody>
					
							
							<tr role="row" class="odd">
								<td class="sorting_1">Project1</td>
								<td>08 Janvier 2021</td>
								<td>Antoine Dione</td>
							</tr>

							<tr role="row" class="odd">
								<td class="sorting_1">Project2</td>
								<td>08 Janvier 2021</td>
								<td>Antoine Dione</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>