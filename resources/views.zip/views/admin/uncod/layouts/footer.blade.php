<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2021 <a href="#">Uncode</a>. Designed by <a href="https://www.faseya.com/" target="_blank">Faseya</a> All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->